package com.example.demoschedlock;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoSchedlockApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoSchedlockApplication.class, args);
	}

}
